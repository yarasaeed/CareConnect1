package com.example.careconnect1.UI;

import static com.example.careconnect1.Utilities.Config.IP;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.careconnect1.Adapters.ProviderOfferAdapter;
import com.example.careconnect1.Model.OffersModel;
import com.example.careconnect1.R;
import com.example.careconnect1.Utilities.AppCompatClass;
import com.example.careconnect1.Utilities.UserData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ProviderOffers extends AppCompatClass {
    private RecyclerView recyclerView;
    private TextView btn_add;
    private UserData userData;
    private ProviderOfferAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_provider_offers);
        setMethods("Offers", "");
    }

    @Override
    public void setInitialize() {
        super.setInitialize();
        btn_add = findViewById(R.id.btn_add_offer);
        recyclerView = findViewById(R.id.recyclerView);
        userData = new UserData(ProviderOffers.this);
    }

    @Override
    public void setActions() {
        super.setActions();
        btn_add.setOnClickListener(v -> {
            Intent intent = new Intent(ProviderOffers.this, AddOffer.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getOffers();
    }

    public void getOffers() {
        ArrayList<OffersModel> arrayList = new ArrayList<>();
        StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "select_offers_where.php?user_id=" + userData.getId(),
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("data");
                            if (jsonArray.length() == 0) {
                                Toast.makeText(ProviderOffers.this, "There are no offers", Toast.LENGTH_SHORT).show();
                            } else {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jSONObject = jsonArray.getJSONObject(i);
                                    String description = jSONObject.optString("description");
                                    String date = jSONObject.optString("time");
                                    String price = jSONObject.optString("price");
                                    String iconBase64 = jSONObject.optString("icon");
                                    Bitmap iconBitmap = decodeBase64(iconBase64);
                                    String id_offer = jSONObject.optString("offer_id");
                                    String used = jSONObject.optString("used");
                                    arrayList.add(new OffersModel(id_offer, iconBitmap, description, date, price, userData.getId(), used));
                                }
                                displayOffers(arrayList);
                            }
                        } catch (JSONException e) {
                            Log.e("ProviderOffers", "Error parsing JSON response: " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("ProviderOffers", "Error getting offers: " + error.getMessage());
                    }
                });
        RequestQueue requestQueue = Volley.newRequestQueue(ProviderOffers.this);
        requestQueue.add(stringRequest);
    }

    private Bitmap decodeBase64(String base64) {
        byte[] decodedBytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }

    private void displayOffers(ArrayList<OffersModel> offersList) {
        adapter = new ProviderOfferAdapter(ProviderOffers.this, offersList);
        recyclerView.setLayoutManager(new LinearLayoutManager(ProviderOffers.this));
        recyclerView.setAdapter(adapter);
    }
}
