package com.example.careconnect1.UI;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.example.careconnect1.R;

public class HelpAndSupport extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_and_support);
    }
}