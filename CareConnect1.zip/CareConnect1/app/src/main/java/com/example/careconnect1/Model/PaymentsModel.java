package com.example.careconnect1.Model;

import android.graphics.Bitmap;

public class PaymentsModel {
    private String payment_id;
    private String parent_id;
    private String parent_name;
    private Bitmap parent_icon;
    private String provider_id;
    private String provider_name;
    private Bitmap provider_icon;
    private String provider_role;
    private String amount;
    private String date;
    private String payment_method;

    public PaymentsModel(String payment_id, String parent_id, String parent_name, Bitmap parent_icon, String provider_id, String provider_name, Bitmap provider_icon, String provider_role, String amount, String date, String payment_method) {
        this.payment_id = payment_id;
        this.parent_id = parent_id;
        this.parent_name = parent_name;
        this.parent_icon = parent_icon;
        this.provider_id = provider_id;
        this.provider_name = provider_name;
        this.provider_icon = provider_icon;
        this.provider_role = provider_role;
        this.amount = amount;
        this.date = date;
        this.payment_method = payment_method;
    }

    // Getters and Setters
    public String getPayment_id() {
        return payment_id;
    }


    public String getParent_id() {
        return parent_id;
    }

    public String getParent_name() {
        return parent_name;
    }

    public Bitmap getParent_icon() {
        return parent_icon;
    }

    public String getProvider_id() {
        return provider_id;
    }

    public String getProvider_name() {
        return provider_name;
    }

    public Bitmap getProvider_icon() {
        return provider_icon;
    }

    public String getProvider_role() {
        return provider_role;
    }

    public String getAmount() {
        return amount;
    }

    public String getDate() {
        return date;
    }

    public String getPayment_method() {
        return payment_method;
    }
}
