package com.example.careconnect1.Utilities;

public interface MyClass {
    void setInitialize();
    void setActions();
}