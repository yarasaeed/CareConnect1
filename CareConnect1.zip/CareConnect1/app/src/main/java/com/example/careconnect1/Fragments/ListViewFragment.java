package com.example.careconnect1.Fragments;

import static com.example.careconnect1.Utilities.Config.IP;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.careconnect1.Adapters.ProvidersAdapter;
import com.example.careconnect1.Model.ProvidersModel;
import com.example.careconnect1.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ListViewFragment extends Fragment {
    private RecyclerView recyclerView;
    private ProvidersAdapter adapter;
    private ArrayList<ProvidersModel> arrayList;
    private SearchView searchView;

    public static ListViewFragment newInstance() {
        return new ListViewFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_list_view, container, false);
        setInitialize(view);
        getProviders();

        // Add the SearchView
        searchView = view.findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filter(newText);
                return true;
            }
        });

        return view;
    }

    private void setInitialize(View view) {
        recyclerView = view.findViewById(R.id.recyclerView);
    }

    private void filter(String text) {
        ArrayList<ProvidersModel> filteredList = new ArrayList<>();
        for (ProvidersModel item : arrayList) {
            if (item.getFname().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
            }
        }
        adapter.getFilter().filter(text);
    }

    private void getProviders() {
        arrayList = new ArrayList<>();
        StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "select_providers.php", response -> {
            try {
                Log.d("ListViewFragment", "Response: " + response);

                JSONObject jsonObject = new JSONObject(response);
                if (jsonObject.getBoolean("status")) {
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject JSONObject = jsonArray.getJSONObject(i);
                        String provider_id = JSONObject.getString("user_id");
                        String email = JSONObject.getString("email");
                        String phone_nb = JSONObject.getString("phone_nb");
                        //String address = providerObject.getString("address");
                        String icon = JSONObject.getString("icon");
                        String role = JSONObject.getString("role");
                        String f_name = JSONObject.getString("f_name");
                        String l_name = JSONObject.getString("l_name");
                        String bio = JSONObject.getString("bio");
                        String gender = JSONObject.getString("gender");

                        arrayList.add(new ProvidersModel(provider_id, f_name, l_name, gender, role, bio,email, phone_nb, icon));
                    }
                    adapter = new ProvidersAdapter(getContext(), arrayList);
                    recyclerView.setAdapter(adapter);
                } else {
                    Log.e("ListViewFragment", "Error: " + jsonObject.getString("error"));
                    Toast.makeText(requireContext(), "Error: " + jsonObject.getString("error"), Toast.LENGTH_SHORT).show();
                }

            } catch (JSONException e) {
                Log.e("ListViewFragment", "Error: " + e.getMessage());
                Toast.makeText(requireContext(), "Error parsing response", Toast.LENGTH_SHORT).show();
            }
        }, error -> {
            Log.e("ListViewFragment", "Volley Error: " + error.getMessage());
            Toast.makeText(requireContext(), "Volley Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
        });

        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);
    }
}