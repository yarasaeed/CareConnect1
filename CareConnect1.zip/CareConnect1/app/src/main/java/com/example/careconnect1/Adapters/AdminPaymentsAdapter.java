package com.example.careconnect1.Adapters;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.careconnect1.Model.PaymentsModel;
import com.example.careconnect1.R;
import com.example.careconnect1.UI.UserProfile;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AdminPaymentsAdapter extends RecyclerView.Adapter<AdminPaymentsAdapter.recyclerHolder> implements Filterable {
    private ArrayList<PaymentsModel> list; // List to store the payments data
    private ArrayList<PaymentsModel> listFull; // A copy of the full payments data (used for filtering)
    private Activity activity; // Reference to the activity using this adapter

    public AdminPaymentsAdapter(Activity activity, ArrayList<PaymentsModel> list) {
        this.list = list;
        this.activity = activity;
        this.listFull = new ArrayList<>(list); // Make a copy of the list for filtering
    }

    // ViewHolder class for holding views of each item in the RecyclerView
    public static class recyclerHolder extends RecyclerView.ViewHolder {
        public TextView parent_name, provider_name, amount, date, payment_method;
        private final ShapeableImageView icon_parent, icon_provider;
        private final LinearLayoutCompat layout_parent, layout_provider;

        public recyclerHolder(View v) {
            super(v);

            parent_name = v.findViewById(R.id.parent_name);
            provider_name = v.findViewById(R.id.provider_name);
            amount = v.findViewById(R.id.amount);
            date = v.findViewById(R.id.date);
            payment_method = v.findViewById(R.id.payment_method);
            layout_parent = v.findViewById(R.id.layout_parent);
            layout_provider = v.findViewById(R.id.layout_provider);
            icon_parent = v.findViewById(R.id.icon_parent);
            icon_provider = v.findViewById(R.id.icon_provider);
        }
    }

    @NonNull
    @Override
    public recyclerHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for each item in the RecyclerView
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_admin_payments, parent, false);
        return new recyclerHolder(v);
    }

    @SuppressLint({"SetTextI18n", "NotifyDataSetChanged"})
    @Override
    public void onBindViewHolder(@NonNull final recyclerHolder holder, @SuppressLint("RecyclerView") final int position) {
        // Get the current payment item
        PaymentsModel currentItem = list.get(position);

        // Set the data for each view in the ViewHolder
        holder.parent_name.setText(currentItem.getParent_name());
        holder.provider_name.setText(currentItem.getProvider_name());
        holder.date.setText(currentItem.getDate());
        holder.amount.setText("USD " + currentItem.getAmount());
        holder.payment_method.setText(currentItem.getPayment_method().toUpperCase(Locale.ROOT));

        // Load the parent icon image using Glide
        Glide.with(activity).asBitmap()
                .load(currentItem.getParent_icon())
                .error(R.drawable.ic_user)
                .into(holder.icon_parent);

        // Load the provider icon image using Glide
        Glide.with(activity).asBitmap()
                .load(currentItem.getProvider_icon())
                .error(R.drawable.ic_user)
                .into(holder.icon_provider);

        // Set click listeners for the customer and provider layouts
        holder.layout_provider.setOnClickListener(v -> {
            // Open UserProfile activity for the provider when clicked
            Intent intent = new Intent(activity, UserProfile.class);
            intent.putExtra("user_id", currentItem.getProvider_id());
            activity.startActivity(intent);
        });
        holder.layout_parent.setOnClickListener(v -> {
            // Open UserProfile activity for the customer when clicked
            Intent intent = new Intent(activity, UserProfile.class);
            intent.putExtra("user_id", currentItem.getParent_id());
            activity.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public Filter getFilter() {
        return filter;
    }

    // Filter for filtering the payments data based on search query
    private final Filter filter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            List<PaymentsModel> filteredList = new ArrayList<>();
            if (charSequence == null || charSequence.length() == 0) {
                filteredList.addAll(listFull); // If the search query is empty, return the full list
            } else {
                String filterPattern = charSequence.toString().toLowerCase().trim();
                for (PaymentsModel item : listFull) {
                    // Check if any field in the payment item matches the search query
                    if (item.getProvider_name().toLowerCase().contains(filterPattern) ||
                            item.getParent_name().toLowerCase().contains(filterPattern) ||
                            item.getDate().toLowerCase().contains(filterPattern) ||
                            item.getProvider_role().toLowerCase().contains(filterPattern) ||
                            item.getPayment_method().toLowerCase().contains(filterPattern) ||
                            item.getAmount().toLowerCase().contains(filterPattern)) {
                        filteredList.add(item); // Add the matching item to the filtered list
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        @SuppressLint("NotifyDataSetChanged")
        @Override
        @SuppressWarnings("unchecked")
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            try {
                list.clear();
                list.addAll((ArrayList<PaymentsModel>) filterResults.values);
                notifyDataSetChanged(); // Update the RecyclerView with the filtered list
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
}
