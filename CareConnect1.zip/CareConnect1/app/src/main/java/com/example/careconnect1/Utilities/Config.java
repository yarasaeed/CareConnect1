package com.example.careconnect1.Utilities;

public class Config {
    public static String IP =  "http://192.168.1.108/CareConnect/";
    public static String USER_IMAGES_DIR = IP + "images/users/";
    public static String OFFER_IMAGES_DIR = IP + "images/offers/";
    public static String MAIN_IMAGES_DIR = IP + "images/main/";
    public static String IPADMIN = IP + "admin/";

}
