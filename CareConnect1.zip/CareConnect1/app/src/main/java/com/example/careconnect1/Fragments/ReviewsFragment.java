package com.example.careconnect1.Fragments;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.careconnect1.Adapters.ProviderReviewsAdapter;
import com.example.careconnect1.Model.ReviewsModel;
import com.example.careconnect1.R;
import com.example.careconnect1.Utilities.Config;
import com.example.careconnect1.Utilities.UserData;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class ReviewsFragment extends Fragment {
    private RecyclerView recyclerView;

    private ArrayList<ReviewsModel> arrayList;

    private UserData userData;

    private ProviderReviewsAdapter adapter;

    public ReviewsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_reviews, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.recyclerView);
        userData = new UserData(requireContext());
        getReviews();
    }

    public void getReviews() {
        arrayList = new ArrayList<>();
        @SuppressLint("SetTextI18n") StringRequest stringRequest = new StringRequest(Request.Method.GET, Config.IP + "select_reviews_where_provider.php?provider_id=" + userData.getId(), response -> {
            int i = 0;
            try {
                JSONObject jsonObject = new JSONObject(response);
                JSONArray jsonArray = new JSONArray(jsonObject.getString("data"));
                if (jsonArray.length() == 0) {
                    Toast.makeText(requireContext(), "There are no reviews", Toast.LENGTH_SHORT).show();
                }

                while (i < jsonArray.length()) {

                    JSONObject reviewObject = jsonArray.getJSONObject(i);
                    String text = reviewObject.optString("ReviewText");
                    String user_id = reviewObject.optString("UserID");
                    String id = reviewObject.optString("ReviewID");
                    String provider_id = reviewObject.optString("ProviderID");
                    String book_id = reviewObject.optString("r_booking_id");
                    JSONObject parentInfoObject = reviewObject.optJSONObject("parent_info");
                    String parent_name = parentInfoObject.optString("f_name") + " " + parentInfoObject.optString("l_name");
                    String parent_iconBase64 = parentInfoObject.optString("icon");
                    String date = reviewObject.optString("date");
                    Bitmap parent_icon = decodeBase64(parent_iconBase64);
                    arrayList.add(new ReviewsModel(id, book_id, user_id, provider_id, text, parent_name, parent_icon, date));
                    i++;
                }
                adapter = new ProviderReviewsAdapter(getContext(), arrayList, false);
                recyclerView.setAdapter(adapter);
            } catch (Exception | Error ignored) {

            }

        }, error -> {

        });
        RequestQueue requestQueue = Volley.newRequestQueue(requireContext());
        requestQueue.add(stringRequest);
    }
    private Bitmap decodeBase64(String base64) {
        byte[] decodedBytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }
}