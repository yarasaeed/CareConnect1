package com.example.careconnect1.Fragments;

import static com.example.careconnect1.Utilities.Config.IP;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.careconnect1.Adapters.AllOffersAdapter;
import com.example.careconnect1.Adapters.AllProvidersAdapter;
import com.example.careconnect1.Adapters.MainImagesAdapter;
import com.example.careconnect1.Model.OffersModel;
import com.example.careconnect1.Model.ProvidersModel;
import com.example.careconnect1.R;
import com.example.careconnect1.UI.AllOffers;
import com.example.careconnect1.UI.ViewActivity;
import com.tbuonomo.viewpagerdotsindicator.DotsIndicator;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;

public class HomeFragment extends Fragment {
    private RecyclerView recyclerViewProviders, recyclerViewOffers;
    private AllOffersAdapter allOffersAdapter;
    private AllProvidersAdapter allProviderAdapter;
    private ArrayList<ProvidersModel> arrayListProviders;
    private ArrayList<OffersModel> arrayListOffers;
    private Runnable runnable = null;
    private Handler handler;


    public HomeFragment() {
        // Required empty public constructor
    }

    public static HomeFragment newInstance() {
        return new HomeFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home, container, false);
        setInitialize(v);
        getProviders();
        getOffers();
        return v;
    }

    private void setInitialize(View v) {
        recyclerViewProviders = v.findViewById(R.id.recyclerViewProviders);
        recyclerViewOffers = v.findViewById(R.id.recyclerViewOffers);
        TextView show_more_offers = v.findViewById(R.id.show_more_offers);
        TextView show_more_providers = v.findViewById(R.id.show_more_providers);
        handler = new Handler();

        show_more_offers.setOnClickListener(v1 -> {
            Intent intent = new Intent(getActivity(), AllOffers.class);
            startActivity(intent);
        });
        show_more_providers.setOnClickListener(v1 -> {
            Intent intent = new Intent(getActivity(), ListViewFragment.class);
            startActivity(intent);
        });
        show_more_providers.setOnClickListener(v1 -> {
            Intent intent = new Intent(getActivity(), ViewActivity.class);
            startActivity(intent);
        });
    }

    private void getOffers() {
        arrayListOffers = new ArrayList<>();
        StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "select_offers.php", response -> {
            try {
                JSONObject jsonObject = new JSONObject(response);
                JSONArray jsonArray = jsonObject.getJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jSONObject = jsonArray.getJSONObject(i);
                    String offer_id = jSONObject.getString("offer_id");
                    String o_provider_id = jSONObject.getString("o_provider_id");
                    String description = jSONObject.getString("description");
                    String iconBase64 = jSONObject.getString("icon");
                    byte[] iconBytes = android.util.Base64.decode(iconBase64, android.util.Base64.DEFAULT);
                    Bitmap iconBitmap = BitmapFactory.decodeByteArray(iconBytes, 0, iconBytes.length);
                    String price = jSONObject.getString("price");
                    String date = jSONObject.getString("time");
                    String f_name = jSONObject.getJSONObject("provider_info").getString("f_name");
                    String l_name = jSONObject.getJSONObject("provider_info").getString("l_name");
                    String provider_iconBase64 = jSONObject.getJSONObject("provider_info").getString("icon");
                    byte[] providerIconBytes = android.util.Base64.decode(provider_iconBase64, android.util.Base64.DEFAULT);
                    Bitmap providerIconBitmap = BitmapFactory.decodeByteArray(providerIconBytes, 0, providerIconBytes.length);
                    String user_role = jSONObject.getJSONObject("provider_info").getString("UserRole");
                    String name = "";
                    if (user_role.toLowerCase(Locale.ROOT).equals("center")) {
                        name = f_name;
                    } else {
                        name = f_name + " " + l_name;
                    }
                    arrayListOffers.add(new OffersModel(offer_id, iconBitmap, description, date, price, o_provider_id, name, providerIconBitmap));
                }
                allOffersAdapter = new AllOffersAdapter(getActivity(), arrayListOffers);
                LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
                recyclerViewOffers.setLayoutManager(layoutManager);
                recyclerViewOffers.setAdapter(allOffersAdapter);
                recyclerViewOffers.setNestedScrollingEnabled(false);
            } catch (Exception e) {
            }
        }, error -> {
            Toast.makeText(getActivity(), "Error getting offers: " + error.getMessage(), Toast.LENGTH_SHORT).show();
        });

        RequestQueue requestQueue = Volley.newRequestQueue(requireContext());
        requestQueue.add(stringRequest);
    }

    private void getProviders() {
        arrayListProviders = new ArrayList<>();
        StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "select_providers.php", response -> {
            try {
                JSONObject jsonObject = new JSONObject(response);
                if (jsonObject.getBoolean("status")) {
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject providerObject = jsonArray.getJSONObject(i);
                        String provider_id = providerObject.getString("user_id");
                        String email = providerObject.getString("email");
                        String phone_nb = providerObject.getString("phone_nb");
                        String icon = providerObject.getString("icon");
                        String role = providerObject.getString("role");
                        String f_name = providerObject.getString("f_name");
                        String l_name = providerObject.getString("l_name");
                        String bio = providerObject.getString("bio");
                        String gender = providerObject.getString("gender");
                        arrayListProviders.add(new ProvidersModel(provider_id, f_name, l_name, gender, role, bio, email, phone_nb, icon));
                    }
                    Activity activity = getActivity();
                    if (activity != null) {
                        allProviderAdapter = new AllProvidersAdapter(activity, arrayListProviders);
                        GridLayoutManager layoutManager = new GridLayoutManager(activity, 2);
                        recyclerViewProviders.setLayoutManager(layoutManager);
                        recyclerViewProviders.setAdapter(allProviderAdapter);
                        recyclerViewProviders.setNestedScrollingEnabled(false);
                    } else {
                    }
                }
            } catch (JSONException e) {
                Toast.makeText(requireContext(), "Error parsing response", Toast.LENGTH_SHORT).show();
            }
        }, error -> {
            Toast.makeText(getActivity(), "Error getting providers: " + error.getMessage(), Toast.LENGTH_SHORT).show();
        });

        RequestQueue requestQueue = Volley.newRequestQueue(requireContext());
        requestQueue.add(stringRequest);
    }


    public void resetHandler() {
        try {
            handler.removeCallbacks(runnable);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        resetHandler();
    }

    @Override
    public void onStop() {
        super.onStop();
        resetHandler();
    }

}
