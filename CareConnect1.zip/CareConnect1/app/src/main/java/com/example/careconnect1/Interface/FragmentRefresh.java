package com.example.careconnect1.Interface;

public interface FragmentRefresh {

     void refreshBookingProvider();
     void refreshProfile();

     void refreshBookingParent();
}
