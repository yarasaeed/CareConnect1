package com.example.careconnect1.Admin;

import static com.example.careconnect1.Utilities.Config.IPADMIN;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.careconnect1.Adapters.AdminUsersAdapter;
import com.example.careconnect1.Model.UsersModel;
import com.example.careconnect1.R;
import com.example.careconnect1.Utilities.AppCompatClass;
import com.google.android.material.appbar.MaterialToolbar;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

public class AllUsers extends AppCompatClass {
    private RecyclerView recyclerView;
    private AdminUsersAdapter adapter;
    private ArrayList<UsersModel> arrayList;
    private SearchView searchView;
    private MaterialToolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_common);
        setMethods("Users", "");
    }

    @Override
    public void setInitialize() {
        super.setInitialize();
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this)); // Set the LayoutManager
        toolbar = findViewById(R.id.generalToolbar);
    }

    @Override
    public void setActions() {
        super.setActions();
        toolbar.inflateMenu(R.menu.menu_search);
        MenuItem item = toolbar.getMenu().findItem(R.id.item_search);
        searchView = (SearchView) item.getActionView();
        getUsers();
    }

    public void getUsers() {
        arrayList = new ArrayList<>();
        StringRequest stringRequest = new StringRequest(Request.Method.GET, IPADMIN + "select_users.php", response -> {
            try {
                JSONObject jsonObject = new JSONObject(response);
                JSONArray jsonArray = jsonObject.getJSONArray("data");
                toolbar.setTitle(jsonArray.length() + " users registered");

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jSONObject = jsonArray.getJSONObject(i);

                    String user_id = jSONObject.getString("user_id");
                    String fname = jSONObject.getString("f_name");
                    String lname = jSONObject.getString("l_name");
                    String email = jSONObject.getString("email");
                    String phone = jSONObject.getString("phone_nb");
                    String role = jSONObject.getString("UserRole");
                    String icon = jSONObject.getString("icon");

                    String name;
                    if (role.toLowerCase(Locale.ROOT).equals("center")) {
                        name = fname;
                    } else {
                        name = fname + " " + lname;
                    }

                    // Decode Base64 icon to Bitmap
                    byte[] iconBytes = Base64.decode(icon, Base64.DEFAULT);
                    Bitmap iconBitmap = BitmapFactory.decodeByteArray(iconBytes, 0, iconBytes.length);

                    arrayList.add(new UsersModel(user_id, name, role, phone, email, iconBitmap));
                }

                adapter = new AdminUsersAdapter(AllUsers.this, arrayList);
                recyclerView.setAdapter(adapter);
                searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {
                        adapter.getFilter().filter(newText);
                        return true;
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(AllUsers.this, "Error parsing data", Toast.LENGTH_SHORT).show();
            }
        }, error -> Toast.makeText(this, "Network error: " + error.toString(), Toast.LENGTH_SHORT).show());

        RequestQueue requestQueue = Volley.newRequestQueue(AllUsers.this);
        requestQueue.add(stringRequest);
    }
}
