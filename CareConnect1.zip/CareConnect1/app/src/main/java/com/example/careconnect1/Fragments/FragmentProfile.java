package com.example.careconnect1.Fragments;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.careconnect1.UI.AddService;
import com.example.careconnect1.UI.LogIn;
import com.example.careconnect1.UI.MainActivity;
import com.example.careconnect1.UI.ProviderOffers;
import com.example.careconnect1.UI.ProviderReviews;
import com.example.careconnect1.Utilities.UserData;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.example.careconnect1.Utilities.Config.IP;
import static com.example.careconnect1.Utilities.Config.USER_IMAGES_DIR;
import static com.example.careconnect1.Utilities.GetImagePath.getRealPath;

import com.example.careconnect1.FileUpload.ImageUploaderClass;
import com.example.careconnect1.R;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class FragmentProfile extends Fragment {

    private TextView text_login;
    private TextInputLayout layout_fname, layout_lname, capacity_layout;
    private LinearLayoutCompat layout_provider;
    boolean edit = false;
    private ScrollView layout_update;
    private UserData userData;
    private ActivityResultLauncher<Intent> activityResultLauncher;
    private ChipGroup chipGroupServices, chipGroupDates;

    Uri uriImage = null;
    String nameOfImage = "";
    private TextInputEditText fname, lname, email, phone, password, bio, gender, capacity;
    private TextView text_name, text_email, text_role;
    private ShapeableImageView btn_reviews, btn_offers;
    private ShapeableImageView btn_logout;
    private ShapeableImageView icon, icon_edit, icon_save;
    private TextView btn_add_service;

    public FragmentProfile() {
    }


    public static FragmentProfile newInstance() {
        return new FragmentProfile();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_profile, container, false);
        setInitialize(v);
        setActions(v);
        //getUserData(); // Add this line to fetch user data
        return v;
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private void edit() {
        fname.setEnabled(edit);
        lname.setEnabled(edit);
        phone.setEnabled(edit);
        bio.setEnabled(edit);
        gender.setEnabled(edit);
        if (edit) {
            icon_save.setVisibility(View.VISIBLE);
            icon_edit.setImageDrawable(getResources().getDrawable(R.drawable.ic_close_2, null));
        } else {
            icon_save.setVisibility(View.INVISIBLE);
            icon_edit.setImageDrawable(getResources().getDrawable(R.drawable.ic_edit, null));

        }
    }

    private void setInitialize(View v) {
        icon_edit = v.findViewById(R.id.icon_edit);
        icon_save = v.findViewById(R.id.icon_save);
        layout_update = v.findViewById(R.id.layout_update);
        icon = v.findViewById(R.id.icon);
        fname = v.findViewById(R.id.fn_edit);
        lname = v.findViewById(R.id.ln_edit);
        email = v.findViewById(R.id.email_edit);
        phone = v.findViewById(R.id.phone_edit);
        password = v.findViewById(R.id.password_edit);
        text_name = v.findViewById(R.id.text_name);
        text_email = v.findViewById(R.id.text_email);
        text_role = v.findViewById(R.id.text_role);
        btn_add_service = v.findViewById(R.id.btn_add_service);

        bio = v.findViewById(R.id.bio_edit);
        gender = v.findViewById(R.id.gender_edit);
        capacity = v.findViewById(R.id.capacity_edit);
        layout_provider = v.findViewById(R.id.layout_provider);
        chipGroupServices = v.findViewById(R.id.chipGroup);
        layout_lname = v.findViewById(R.id.ln_layout);
        capacity_layout = v.findViewById(R.id.capacity_layout);
        layout_fname = v.findViewById(R.id.fn_layout);
        btn_offers = v.findViewById(R.id.btn_offers);
        btn_reviews = v.findViewById(R.id.btn_reviews);
        btn_logout = v.findViewById(R.id.btn_logout);

        if (getActivity() != null) {
            userData = new UserData(getActivity());
        }
    }

    private void setActions(View v) {
        icon_edit.setOnClickListener(v16 -> {
            edit = !edit;
            edit();
        });
        icon.setOnClickListener(v2 -> checkPermission());
        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        if (result.getData() != null) {
                            uriImage = result.getData().getData();
                        }
                        if (uriImage != null) {
                            icon.setImageURI(uriImage);

                        }
                    }
                });
        btn_add_service.setOnClickListener(v12 -> {
            Intent intent = new Intent(getActivity(), AddService.class);
            startActivity(intent);
        });
        btn_offers.setOnClickListener(v12 -> {
            Intent intent = new Intent(getActivity(), ProviderOffers.class);
            startActivity(intent);
        });
        btn_reviews.setOnClickListener(v12 -> {
            Intent intent = new Intent(getActivity(), ProviderReviews.class);
            startActivity(intent);
        });
        icon_save.setOnClickListener(v13 -> {
            edit = !edit;
            edit();
            updateProfile();
        });
        btn_logout.setOnClickListener(v14 -> {
            if (getActivity() != null) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Logout");
                builder.setMessage("Are you sure?");
                builder.setIcon(R.drawable.ic_logout);
                builder.setPositiveButton("Yes", (dialog, which) -> {
                    userData.logout();
                    Intent intent = new Intent(getActivity(), LogIn.class);
                    intent.putExtra("tab", "1");
                    startActivity(intent);
                    if (getActivity() != null) {
                        getActivity().finish();
                    }
                });
                builder.setNegativeButton("No", null);
                builder.show();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        if (getActivity() != null) {
            userData = new UserData(getActivity());
            if (userData.isLogin()) {
                layout_update.setVisibility(View.VISIBLE);
                getUserData();
            } else {
                layout_update.setVisibility(View.GONE);
            }
        }
    }


    private void getUserData() {
        if (getActivity() != null) {
            @SuppressLint("SetTextI18n") StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "select_user.php?id=" + userData.getId(), response -> {


                int i = 0;
                try {
                    //  Log.e("anyText", response); // Debug log for response
                    Log.e("JSON Response", response); // Add this line

                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = new JSONArray(jsonObject.getString("data"));


                    // Debug log for the whole JSON object
                    Log.d("UserDataResponse", "JSON Object: " + jsonObject.toString());

                    Log.d("UserDataResponse", "Data Array: " + jsonArray.toString());
                    while (i < jsonArray.length()) {
                        JSONObject jSONObject = jsonArray.getJSONObject(i);
                        fname.setText(jSONObject.optString("f_name"));
                        lname.setText(jSONObject.optString("l_name"));
                        email.setText(jSONObject.optString("email"));
                        phone.setText(jSONObject.optString("phone_nb"));
                        password.setText(jSONObject.optString("password"));
                        text_email.setText(jSONObject.optString("email"));
                        text_name.setText(jSONObject.optString("f_name") + " " + jSONObject.optString("l_name"));
                        text_role.setText(jSONObject.getString("UserRole"));
                        gender.setText(jSONObject.optString("gender"));
                        bio.setText(jSONObject.optString("bio"));
                        capacity.setText(jSONObject.optString("capacity"));
                        // Load user image
                        String iconBase64 = jSONObject.optString("icon");
                        if (!iconBase64.isEmpty()) {
                            Log.d("Base64", "Received Base64: " + iconBase64); // Debug log for Base64 image data

                            try {
                                byte[] decodedBytes = Base64.decode(iconBase64, Base64.DEFAULT | Base64.NO_WRAP);
                                Log.d("Base64", "Decoded Bytes: " + Arrays.toString(decodedBytes)); // Debug log for decoded bytes

                                Bitmap decodedBitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
                                if (decodedBitmap != null) {
                                    icon.setImageBitmap(decodedBitmap);
                                } else {
                                    Log.e("Bitmap", "Decoded bitmap is null"); // Debug log for null bitmap
                                }
                            } catch (IllegalArgumentException e) {
                                Log.e("Bitmap", "Failed to decode bitmap: " + e.getMessage()); // Log error if decoding fails
                            }
                        } else {
                            Log.e("Base64", "Empty Base64 string"); // Debug log for empty Base64 string
                        }
                        if (jSONObject.getString("UserRole").equals("parent")) {
                            layout_provider.setVisibility(View.GONE);
                            btn_offers.setVisibility(View.GONE);
                            btn_reviews.setVisibility(View.GONE);
                            capacity_layout.setVisibility(View.GONE);
                        } else if (jSONObject.getString("UserRole").equals("babysitter")) {
                            btn_offers.setVisibility(View.GONE);
                            capacity_layout.setVisibility(View.GONE);


                        } else if (jSONObject.getString("UserRole").equals("center")) {
                            layout_fname.setHint("Name");
                            layout_lname.setVisibility(View.GONE);
                            gender.setVisibility(View.GONE);
                            lname.setText("-");
                            gender.setText("-");
                        } else {//if admin{}
                            layout_provider.setVisibility(View.GONE);
                            btn_offers.setVisibility(View.GONE);
                            btn_reviews.setVisibility(View.GONE);
                            capacity_layout.setVisibility(View.GONE);
                        }
                        i++;


                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.e("UserDataResponse", "Error parsing JSON: " + e.getMessage()); // Error log for JSON parsing
                    //Toast.makeText(getActivity(), "Error parsing user data", Toast.LENGTH_SHORT).show(); // Error message for user
                }

            },
                    error -> {

                    });

            RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
            requestQueue.add(stringRequest);
        }

    }


    private void getServices() {
        if (getActivity() != null) {
            @SuppressLint("SetTextI18n") StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "select_services_where.php?user_id=" + userData.getId(), response -> {
                int i = 0;
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = new JSONArray(jsonObject.getString("data"));
                    while (i < jsonArray.length()) {
                        JSONObject jSONObject = jsonArray.getJSONObject(i);
                        final Chip chip = (Chip) View.inflate(getActivity(), R.layout.chip_items, null);
                        chip.setText(jSONObject.getString("ServiceName") + " - " + jSONObject.getString("ServicePrice"));
                        chipGroupServices.addView(chip);
                        chip.setOnCloseIconClickListener(view1 -> {
                            chipGroupServices.removeView(chip);
                            try {
                                removeService(jSONObject.getString("ServiceID"));
                            } catch (JSONException e) {
                                throw new RuntimeException(e);
                            }
                        });

                        i++;
                    }
                } catch (Exception | Error ignored) {

                }

            }, error -> {

            });
            RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
            requestQueue.add(stringRequest);
        }
    }

    private void removeService(String service_id) {
        if (getActivity() != null) {
            StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "delete_service.php?id=" + service_id, response -> {
                Toast.makeText(getActivity(), response.trim(), Toast.LENGTH_SHORT).show();
            }, error -> {
            });
            RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
            requestQueue.add(stringRequest);
        }
    }

    private void updateProfile() {
        if (getActivity() != null) {
            StringRequest stringRequest = new StringRequest(Request.Method.POST, IP + "update_user.php",
                    response -> Toast.makeText(getActivity(), response, Toast.LENGTH_SHORT).show(),
                    error -> {
                        // Handle error
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> map = new HashMap<>();
                    map.put("fname", fname.getText().toString());
                    map.put("lname", lname.getText().toString());
                    map.put("email", email.getText().toString());
                    map.put("gender", gender.getText().toString());
                    map.put("password", password.getText().toString());
                    map.put("phone", phone.getText().toString());
                    map.put("user_id", userData.getId());
                    map.put("bio", bio.getText().toString());
                    map.put("capacity", capacity.getText().toString());

                    // Handle icon data
                    if (uriImage != null) {
                        Bitmap bitmap = null;
                        try {
                            bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), uriImage);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        if (bitmap != null) {
                            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                            bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                            byte[] byteArray = byteArrayOutputStream.toByteArray();
                            String iconBase64 = Base64.encodeToString(byteArray, Base64.DEFAULT);
                            map.put("icon", iconBase64);
                        }
                    }

                    return map;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
            requestQueue.add(stringRequest);
        }
    }


    private void checkPermission() {
        if (getActivity() != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED) {
                    openGallery();
                } else {
                    ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_MEDIA_IMAGES}, 100);
                }
            } else {
                if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    openGallery();
                } else {
                    ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);
                }
            }
        }
    }

    private void openGallery() {
        if (getActivity() != null) {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
            activityResultLauncher.launch(intent);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100 && (grantResults.length > 0) && (grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
            openGallery();
        } else {
            Toast.makeText(getActivity(), "Permission denied", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            if (data != null && data.getData() != null) {
                uriImage = data.getData();
                icon.setImageURI(uriImage);

            }
        }
    }

    // Method to get real path from URI
    private String getRealPath(Activity activity, Uri uri) {
        String filePath = "";
        if (DocumentsContract.isDocumentUri(activity, uri)) {
            String wholeID = DocumentsContract.getDocumentId(uri);
            String id = wholeID.split(":")[1];
            String[] column = {MediaStore.Images.Media.DATA};
            String sel = MediaStore.Images.Media._ID + "=?";
            Cursor cursor = activity.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, column, sel, new String[]{id}, null);
            int columnIndex = cursor.getColumnIndex(column[0]);
            if (cursor.moveToFirst()) {
                filePath = cursor.getString(columnIndex);
            }
            cursor.close();
        } else {
            String[] filePathColumn = {MediaStore.Images.Media.DATA};
            Cursor cursor = activity.getContentResolver().query(uri, filePathColumn, null, null, null);
            if (cursor != null) {
                cursor.moveToFirst();
                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                filePath = cursor.getString(columnIndex);
                cursor.close();
            }
        }
        return filePath;
    }

    // Method to convert URI to base64 string
    private String getBase64FromUri(Uri uri) {
        try {
            InputStream inputStream = getActivity().getContentResolver().openInputStream(uri);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                byteArrayOutputStream.write(buffer, 0, bytesRead);
            }
            byte[] imageBytes = byteArrayOutputStream.toByteArray();
            return Base64.encodeToString(imageBytes, Base64.DEFAULT);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}