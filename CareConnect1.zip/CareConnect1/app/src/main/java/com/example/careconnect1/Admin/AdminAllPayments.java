package com.example.careconnect1.Admin;

import static com.example.careconnect1.Utilities.Config.IPADMIN;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.careconnect1.Adapters.AdminPaymentsAdapter;
import com.example.careconnect1.Model.PaymentsModel;
import com.example.careconnect1.R;
import com.example.careconnect1.Utilities.AppCompatClass;
import com.google.android.material.appbar.MaterialToolbar;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class AdminAllPayments extends AppCompatClass {
    private static final String TAG = "AdminAllPayments";

    private RecyclerView recyclerView;
    private AdminPaymentsAdapter adapter;
    private ArrayList<PaymentsModel> arrayList;
    private SearchView searchView;
    private MaterialToolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_common);
        setMethods("Payments", "");
    }

    @Override
    public void setInitialize() {
        super.setInitialize();
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this)); // Set the LayoutManager
        toolbar = findViewById(R.id.generalToolbar);
        arrayList = new ArrayList<>();
        adapter = new AdminPaymentsAdapter(this, arrayList); // Initialize adapter with empty list
        recyclerView.setAdapter(adapter); // Attach adapter to RecyclerView
    }

    @Override
    public void setActions() {
        super.setActions();
        toolbar.inflateMenu(R.menu.menu_search);
        MenuItem item = toolbar.getMenu().findItem(R.id.item_search);
        searchView = (SearchView) item.getActionView();
        getPayments();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getPayments();
    }

    public void getPayments() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, IPADMIN + "select_payments.php", response -> {
            try {
                JSONObject jsonObject = new JSONObject(response);
                if (jsonObject.getBoolean("status")) {
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    arrayList.clear(); // Clear the arrayList before adding new items
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject paymentObject = jsonArray.getJSONObject(i);

                        // Payment info
                        String payment_id = paymentObject.getString("PaymentID");
                        String date = paymentObject.getString("PaymentDate");
                        String amount = paymentObject.getString("AmountPaid");
                        String payment_method = paymentObject.getString("PaymentMethod");

                        // Parent info
                        JSONObject parentInfo = paymentObject.getJSONObject("parent_info");
                        String parent_id = parentInfo.getString("user_id");
                        String parent_f_name = parentInfo.getString("f_name");
                        String parent_l_name = parentInfo.getString("l_name");
                        String parent_icon = parentInfo.getString("icon");
                        String parent_name = parent_f_name + " " + parent_l_name;

                        // Decode Base64 parent icon to Bitmap
                        byte[] parentIconBytes = Base64.decode(parent_icon, Base64.DEFAULT);
                        Bitmap parentIconBitmap = BitmapFactory.decodeByteArray(parentIconBytes, 0, parentIconBytes.length);

                        // Provider info
                        JSONObject providerInfo = paymentObject.getJSONObject("provider_info");
                        String provider_id = providerInfo.getString("user_id");
                        String provider_f_name = providerInfo.getString("f_name");
                        String provider_l_name = providerInfo.getString("l_name");
                        String provider_icon = providerInfo.getString("icon");
                        String role = providerInfo.getString("UserRole");
                        String provider_name = role.equalsIgnoreCase("center") ? provider_f_name : provider_f_name + " " + provider_l_name;

                        // Decode Base64 provider icon to Bitmap
                        byte[] providerIconBytes = Base64.decode(provider_icon, Base64.DEFAULT);
                        Bitmap providerIconBitmap = BitmapFactory.decodeByteArray(providerIconBytes, 0, providerIconBytes.length);

                        arrayList.add(new PaymentsModel(payment_id, parent_id, parent_name, parentIconBitmap, provider_id, provider_name, providerIconBitmap, role, amount, date, payment_method));
                    }
                    adapter.notifyDataSetChanged(); // Notify adapter of data changes

                    searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                        @Override
                        public boolean onQueryTextSubmit(String query) {
                            return false;
                        }

                        @Override
                        public boolean onQueryTextChange(String newText) {
                            adapter.getFilter().filter(newText);
                            return true;
                        }
                    });
                } else {
                    Toast.makeText(AdminAllPayments.this, "No data found", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(AdminAllPayments.this, "Error parsing data", Toast.LENGTH_SHORT).show();
            }
        }, error -> {
            Toast.makeText(this, "Network error: " + error.toString(), Toast.LENGTH_SHORT).show();
        });

        RequestQueue requestQueue = Volley.newRequestQueue(AdminAllPayments.this);
        requestQueue.add(stringRequest);
    }
}
