package com.example.careconnect1.Fragments;
import static com.example.careconnect1.Utilities.Config.IP;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.careconnect1.Adapters.ProviderBookingAdapter;
import com.example.careconnect1.Interface.FragmentRefresh;
import com.example.careconnect1.Model.BookingModel;
import com.example.careconnect1.Model.ServiceModel;
import com.example.careconnect1.R;
import com.example.careconnect1.Utilities.UserData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class FragmentBookingProvider extends Fragment implements FragmentRefresh {

    private TextView text_no_book;
    private UserData userData;

    private RecyclerView recyclerView;

    private ArrayList<BookingModel> arrayList;

    private ProviderBookingAdapter adapter;

    public FragmentBookingProvider() {
    }


    public static FragmentBookingProvider newInstance() {
        return new FragmentBookingProvider();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_booking_provider, container, false);
        setInitialize(v);
        setActions(v);

        return v;
    }

    private void setInitialize(View v) {
        text_no_book = v.findViewById(R.id.text_no_book);
        recyclerView = v.findViewById(R.id.recyclerView);
    }

    private void setActions(View v) {
        if (getActivity() != null) {
            userData = new UserData(getActivity());
            if (userData.isLogin()) {

                getBooking();
            }
        }
    }


    public void getBooking() {
        Log.d("FragmentBookingProvider", "Fetching booking data...");
        arrayList = new ArrayList<>();
        String url = IP + "select_provider_booking.php?provider_id=" + userData.getId();
        Log.d("URL", url); // Log the URL being called
        @SuppressLint("SetTextI18n") StringRequest stringRequest = new StringRequest(Request.Method.GET, url, response -> {
            try {
                Log.d("FragmentBookingProvider", "Response: " + response);
                JSONObject jsonObject = new JSONObject(response);
                boolean success = jsonObject.getBoolean("success");
                if (success) {
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    if (jsonArray.length() == 0) {
                        text_no_book.setVisibility(View.VISIBLE);
                        text_no_book.setText("You didn't receive any booking request");
                        recyclerView.setVisibility(View.GONE); // Hide RecyclerView
                    } else {
                        text_no_book.setVisibility(View.GONE);
                        recyclerView.setVisibility(View.VISIBLE); // Show RecyclerView
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jSONObject = jsonArray.getJSONObject(i);
                            // Extract booking details
                            String bookingTime = jSONObject.getString("bookingTime");
                            String bookingDate = jSONObject.getString("bookingDate");
                            String id_book = jSONObject.getString("bookingID");
                            String book_status = jSONObject.getString("book_status");
                            String rejected_cause = jSONObject.getString("rejected_cause");

                            // Extract user data
                            JSONObject parent_info = jSONObject.getJSONObject("parent_info");
                            String parent_email = parent_info.getString("email");
                            String parent_id = parent_info.getString("user_id");
                            String parent_name = parent_info.getString("f_name") + " " + parent_info.getString("l_name");
                            String parent_iconBase64 = parent_info.getString("icon");

                            // Decode parent icon from base64
                            Bitmap parent_icon = decodeBase64(parent_iconBase64);

                            // Extract provider data
                            JSONObject provider_info = jSONObject.getJSONObject("provider_info");
                            String provider_email = provider_info.getString("email");
                            String provider_id = provider_info.getString("user_id");
                            String provider_name = provider_info.getString("f_name") + " " + provider_info.getString("l_name");
                            String provider_iconBase64 = provider_info.getString("icon");

                            // Decode provider icon from base64
                            Bitmap provider_icon = decodeBase64(provider_iconBase64);

                            String offer_id = "", offer_price = "", offer_time = "", offer_description = "", offer_icon = "";
                            if (!jSONObject.isNull("offer_info")) {
                                // Extract offer data
                                JSONObject offer_info = jSONObject.getJSONObject("offer_info");
                                offer_id = offer_info.getString("offer_id");
                                offer_description = offer_info.getString("description");
                                offer_price = offer_info.getString("price");
                                offer_time = offer_info.getString("time");
                                offer_icon = offer_info.getString("icon");
                            }
                            String payment_id = "", payment_type = "", payment_amount = "";
                            if (!jSONObject.isNull("payment_info")) {
                                // Extract payment data
                                JSONObject payment_info = jSONObject.getJSONObject("payment_info");
                                payment_id = payment_info.getString("PaymentID");
                                payment_type = payment_info.getString("PaymentMethod");
                                payment_amount = payment_info.getString("AmountPaid");
                            }
                            ArrayList<ServiceModel> arrayService = new ArrayList<>();
                            if (!jSONObject.getJSONArray("services").isNull(0)) {
                                // Extract service data
                                JSONArray jsonArrayServices = jSONObject.getJSONArray("services");
                                for (int j = 0; j < jsonArrayServices.length(); j++) {
                                    JSONObject jb = jsonArrayServices.getJSONObject(j);
                                    String serviceId = jb.getString("ServiceID");
                                    String serviceName = jb.getString("ServiceName");
                                    String servicePrice = jb.getString("ServicePrice");
                                    String serviceProviderId = jb.getString("s_provider_id");
                                    arrayService.add(new ServiceModel(serviceId, serviceName, servicePrice, serviceProviderId));
                                }
                            }

                            // Create a BookingModel object with the extracted data and add it to the list
                            arrayList.add(new BookingModel(id_book, bookingDate, bookingTime, parent_id, parent_name, parent_email, parent_icon,
                                    provider_id, provider_name, provider_email, provider_icon, book_status, offer_id, offer_price,
                                    offer_time, offer_description, offer_icon, payment_id, payment_type, payment_amount, rejected_cause, arrayService));
                        }

                        // Set up the adapter with the list of bookings
                        adapter = new ProviderBookingAdapter(getActivity(), arrayList, this);
                        recyclerView.setAdapter(adapter);
                    }
                } else {
                    // Handle unsuccessful response
                    Log.e("FragmentBookingProvider", "Error: " + jsonObject.getString("message"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }, error -> {
            // Handle error
            Log.e("FragmentBookingProvider", "Error: " + error.getMessage());
        });
        if (getActivity() != null) {
            RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
            requestQueue.add(stringRequest);
        }
    }

    // Method to decode base64 string into Bitmap
    public Bitmap decodeBase64(String encodedImage) {
        byte[] decodedBytes = Base64.decode(encodedImage, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }

    @Override
    public void refreshBookingProvider() {
        getBooking();
    }

    @Override
    public void refreshProfile() {

    }

    @Override
    public void refreshBookingParent() {

    }
}
