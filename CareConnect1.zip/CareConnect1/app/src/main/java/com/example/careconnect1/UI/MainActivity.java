package com.example.careconnect1.UI;

import static com.example.careconnect1.Utilities.Config.IP;
import static com.example.careconnect1.Utilities.Config.USER_IMAGES_DIR;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.careconnect1.Admin.AdminActivity;
import com.example.careconnect1.Fragments.AboutFragment;
import com.example.careconnect1.Fragments.FragmentBookingParent;
import com.example.careconnect1.Fragments.FragmentBookingProvider;
import com.example.careconnect1.Fragments.FragmentPolicy;
import com.example.careconnect1.Fragments.HomeFragment;
import com.example.careconnect1.Fragments.FragmentProfile;
import com.example.careconnect1.Fragments.FragmentSupport;
import com.example.careconnect1.Fragments.ReviewsFragment;
import com.example.careconnect1.R;
import com.example.careconnect1.Utilities.AppCompatClass;
import com.example.careconnect1.Utilities.UserData;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.navigation.NavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Locale;

public class MainActivity extends AppCompatClass {
    private BottomNavigationView bottomNavigationView;
    private FragmentManager fragmentManager;
    private ShapeableImageView icon, icon_small;
    private UserData userData;
    private TextView name, role;
    private ShapeableImageView icon_menu;
    private NavigationView navigationView;
    private String user_role = "";
    private String current_tab = "1";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setMethods("", "");

        fragmentManager = getSupportFragmentManager();
        openFragment(new HomeFragment());//deafult to open home on login
        userData = new UserData(MainActivity.this); // Initialize userData here
        getUserData(userData.getId());
    }

    @SuppressLint({"NonConstantResourceId", "UseCompatLoadingForDrawables"})
    public void loadNavigation() {
        // DrawerLayout by id
        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);

        icon_menu.setOnClickListener(v -> {
            // Check if drawer layout open it close and vice versa
            if (!drawerLayout.isDrawerOpen(GravityCompat.START)) {
                drawerLayout.openDrawer(GravityCompat.START);
            } else {
                drawerLayout.closeDrawer(GravityCompat.START);
            }
        });

        // Listener to the navigation bar item for bottom and drawer
        navigationView.setNavigationItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_profile) {
                openFragment(new FragmentProfile());
            } else if (itemId == R.id.nav_help) {
                openFragment(new FragmentSupport());
            } else if (itemId == R.id.nav_policy) {
                openFragment(new FragmentPolicy());
            } else if (itemId == R.id.nav_rate) {
                openAppInPlayStore();
            } else if (itemId == R.id.nav_share) {
                shareApp();
            } else if (itemId == R.id.nav_more) {
                openMoreApps();
            } else if (itemId == R.id.nav_logout) {
                logoutUser();
            } else if (itemId == R.id.nav_about) {
                openFragment(new AboutFragment());
            } else if (itemId == R.id.nav_admin) {
                openActivity(AdminActivity.class);
            } else if (itemId == R.id.nav_payments) {
                openActivity(AllPayments.class);
            } else if (itemId == R.id.nav_reviews) {
                if (!user_role.equals("parent")) {
                    openFragment(new ReviewsFragment());
                }
            } else if (itemId == R.id.nav_offers) {
                if (user_role.equals("parent")) {
                    openActivity(AllOffers.class);
                } else {
                    openActivity(ProviderOffers.class);
                }
            } else if (itemId == R.id.booking) {
                if (user_role.equals("parent")) {
                    openFragment(new FragmentBookingParent());
                } else if (user_role.equals("admin")) {
                    return false;
                } else {
                    openFragment(new FragmentBookingProvider());
                }
            }
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });
    }


    @Override
    public void setInitialize() {
        super.setInitialize();
        getWindow().setStatusBarColor(getResources().getColor(R.color.status, null));
        bottomNavigationView = findViewById(R.id.bottomNavigation);
        icon_menu = findViewById(R.id.icon_menu);
        icon_small = findViewById(R.id.icon_small);
        icon = findViewById(R.id.icon);
        role = findViewById(R.id.user_role);
        navigationView = findViewById(R.id.nav2);
        name = findViewById(R.id.user_name);
        userData = new UserData(MainActivity.this);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if (bundle != null) {
            current_tab = bundle.getString("tab", "1");
        }
    }

    private void getUserData(String id) {// get user data to change nav drawer according to user type
        StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "select_user.php?id=" + id, new Response.Listener<String>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(String response) {
                int i = 0;
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = new JSONArray(jsonObject.getString("data"));
                    if (jsonArray.length() == 0) {
                        userData.logout();

                        Menu nav_Menu = navigationView.getMenu();
                        nav_Menu.findItem(R.id.nav_admin).setVisible(false);
                        nav_Menu.findItem(R.id.nav_offers).setVisible(false);
                        nav_Menu.findItem(R.id.nav_reviews).setVisible(false);
                        nav_Menu.findItem(R.id.nav_payments).setVisible(false);
                    }
                    while (i < jsonArray.length()) {
                        JSONObject jSONObject = jsonArray.getJSONObject(i);
                        user_role = jSONObject.getString("UserRole");
                        if (user_role.toLowerCase(Locale.ROOT).equals("admin") || user_role.toLowerCase(Locale.ROOT).equals("center")) {
                            name.setText(jSONObject.getString("f_name"));
                        } else if (user_role.toLowerCase(Locale.ROOT).equals("babysitter") || user_role.toLowerCase(Locale.ROOT).equals("parent")) {
                            name.setText(jSONObject.getString("f_name") + " " + jSONObject.getString("l_name"));
                        }

                        role.setText(user_role.toUpperCase(Locale.ROOT));
                        // Decode the base64 image data
                        byte[] decodedString = Base64.decode(jSONObject.getString("icon"), Base64.DEFAULT);
                        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

                        // Set the decoded image to the ImageView using Glide
                        Glide.with(MainActivity.this)
                                .load(decodedByte)
                                .error(R.drawable.ic_user) // Error placeholder if loading fails
                                .into(icon);

                        Glide.with(MainActivity.this)
                                .load(decodedByte)
                                .error(R.drawable.ic_person) // Error placeholder if loading fails
                                .into(icon_small);
                        if (user_role.toLowerCase(Locale.ROOT).equals("parent")) {
                            Menu nav_Menu = navigationView.getMenu();
                            nav_Menu.findItem(R.id.nav_offers).setVisible(false);
                            nav_Menu.findItem(R.id.nav_reviews).setVisible(false);
                        }
                        if (user_role.toLowerCase(Locale.ROOT).equals("admin")) {
                            Menu nav_Menu = navigationView.getMenu();
                            nav_Menu.findItem(R.id.nav_offers).setVisible(false);
                            nav_Menu.findItem(R.id.nav_reviews).setVisible(false);
                            nav_Menu.findItem(R.id.nav_payments).setVisible(false);
                            nav_Menu.findItem(R.id.booking).setVisible(false);
                        }
                        if (!user_role.toLowerCase(Locale.ROOT).equals("admin")) {
                            Menu nav_Menu = navigationView.getMenu();
                            nav_Menu.findItem(R.id.nav_admin).setVisible(false);
                        }
                        if (user_role.toLowerCase(Locale.ROOT).equals("center") ||
                                user_role.toLowerCase(Locale.ROOT).equals("babysitter")) {
                            Menu nav_Menu = navigationView.getMenu();
                            nav_Menu.findItem(R.id.nav_payments).setVisible(false);
                        }
                        i++;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                bottomNavigationView.setOnItemSelectedListener(item -> {
                    if (item.getItemId() == R.id.home) {
                        openFragment(new HomeFragment());
                        return true;
                    } else if (item.getItemId() == R.id.support) {
                        openFragment(new FragmentSupport());
                        return true;
                    } else if (item.getItemId() == R.id.profile) {
                        openFragment(new FragmentProfile());
                        return true;
                    } else if (item.getItemId() == R.id.booking) {
                        if (user_role.equals("parent")) {
                            openFragment(new FragmentBookingParent());
                        } else if (user_role.equals("admin")) {
                            return false;
                        } else {
                            openFragment(new FragmentBookingProvider());
                        }
                        return true;
                    }
                    return false;
                });

                switch (current_tab) {
                    case "2":
                        if (user_role.equals("parent")) {
                            openFragment(new FragmentBookingParent());
                        } else {

                            openFragment(new FragmentBookingProvider());
                        }
                        bottomNavigationView.setSelectedItemId(R.id.booking);

                        break;
                    case "3":
                        openFragment(new FragmentSupport());
                        bottomNavigationView.setSelectedItemId(R.id.support);
                        break;
                    case "4":
                        openFragment(new FragmentProfile());
                        bottomNavigationView.setSelectedItemId(R.id.profile);
                        break;
                    default:
                        openFragment(new HomeFragment());
                        bottomNavigationView.setSelectedItemId(R.id.home);
                        break;
                }
                loadNavigation();
            }
        }, error -> {
        });
        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        requestQueue.add(stringRequest);
    }


    private void openFragment(Fragment fragment) {
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.commit();
    }

    private void openActivity(Class<?> activity) {
        Intent intent = new Intent(MainActivity.this, activity);
        startActivity(intent);
    }

    private void logoutUser() {
        // Clear any user session data or preferences
        // For example, clear SharedPreferences or reset user authentication status
        // Navigate to the login screen or any other desired screen
        Intent intent = new Intent(this, LogIn.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish(); // Finish current activity to prevent returning to it when pressing back
    }

    private void openAppInPlayStore() {
        Uri uri = Uri.parse("market://details?id=" + getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
        }
    }

    private void shareApp() {
        Intent sharingIntent = new Intent(Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        String shareBody = "https://play.google.com/store/apps/details?id=" + getPackageName();
        sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Let's find childcare centers and babysitters near you!");
        sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
        startActivity(Intent.createChooser(sharingIntent, "Share via"));
    }

    private void openMoreApps() {
        Uri url = Uri.parse("http://play.google.com/store/search?q=pub:childcare+centers+and+babysitters+finder");
        Intent launch = new Intent(Intent.ACTION_VIEW, url);
        startActivity(launch);
    }
}
