package com.example.careconnect1.UI;

import static com.example.careconnect1.Utilities.Config.IP;
import static com.example.careconnect1.Utilities.Config.OFFER_IMAGES_DIR;
import static com.example.careconnect1.Utilities.Config.USER_IMAGES_DIR;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.careconnect1.Adapters.BookReviewsAdapter;
import com.example.careconnect1.Model.ReviewsModel;
import com.example.careconnect1.Model.ServiceModel;
import com.example.careconnect1.R;
import com.example.careconnect1.Utilities.AppCompatClass;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.imageview.ShapeableImageView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

public class BookInfo extends AppCompatClass {
    private  TextView date, payment_info,status;
    private String book_id;
    private  ArrayList<ReviewsModel> arrayList;
    private  TextView provider_name, parent_name;
    private  ShapeableImageView ic_help,icon_provider, icon_offer, icon_parent
            ,icon_call_provider,icon_call_parent, icon_email_provider, icon_email_parent;
    private  TextView offer_info;
    private LinearLayoutCompat layout_offer, layout_service ;
    RelativeLayout layout_provider, layout_parent;
    private ChipGroup chipGroup;


    private BookReviewsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_info);
        setMethods("Book info","");
    }

    @Override
    public void setInitialize() {
        super.setInitialize();
        ic_help =findViewById(R.id.ic_help);
        status =findViewById(R.id.status);

        layout_provider =findViewById(R.id.layout_provider);
        layout_parent =findViewById(R.id.layout_parent);
        icon_email_parent =findViewById(R.id.icon_email_parent);
        icon_email_provider =findViewById(R.id.icon_email_provider);
        icon_call_parent=findViewById(R.id.icon_call_parent);
        icon_call_provider =findViewById(R.id.icon_call_provider);
        icon_parent =findViewById(R.id.icon_parent);
        parent_name =findViewById(R.id.parent_name);
        payment_info =findViewById(R.id.payment_info);
        date =findViewById(R.id.booking_date);
        provider_name =findViewById(R.id.provider_name);
        icon_provider =findViewById(R.id.icon_provider);
        icon_offer =findViewById(R.id.icon_offer);
        offer_info =findViewById(R.id.offer_info);
        layout_offer =findViewById(R.id.layout_offer);
        layout_service =findViewById(R.id.layout_services);
        chipGroup =findViewById(R.id.chipGroup);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if(bundle != null){ // from customer booking adapter
            book_id = bundle.getString("book_id","");
        }
    }

    @Override
    public void setActions() {
        super.setActions();
        getInfo();
    }

    public void getInfo() {
        arrayList = new ArrayList<>();
        @SuppressLint("SetTextI18n")
        StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "select_book.php?book_id=" + book_id, response -> {
            int i = 0;

            response = response.substring(response.indexOf("{"));
            if (response != null && !response.isEmpty()) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = new JSONArray(jsonObject.getString("data"));

                    while (i < jsonArray.length()) {
                        Log.d("BookInfo", "hi1");
                        JSONObject jSONObject = jsonArray.getJSONObject(i);
                        String bookingTime = jSONObject.getJSONObject("booking_info").getString("bookingTime");
                        String bookingDate = jSONObject.getJSONObject("booking_info").getString("bookingDate");
                        String id_book = jSONObject.getJSONObject("booking_info").getString("bookingID");
                        String book_status = jSONObject.getJSONObject("booking_info").getString("book_status");
                        String rejection_cause = jSONObject.getJSONObject("booking_info").getString("rejected_cause");
                        Log.d("BookInfo", "hi2");

                        JSONObject parentInfo = jSONObject.getJSONObject("booking_info").getJSONObject("parent_info");
                        String parent_name = parentInfo.getString("f_name") +
                                " " + parentInfo.getString("l_name");
                        String parent_email = parentInfo.getString("email");
                        String parent_id = parentInfo.getString("parent_id");
                        String parent_icon = parentInfo.getString("icon");
                        String parent_phone = parentInfo.getString("phone_nb");
                        Log.d("BookInfo", "hi3");

                        JSONObject providerInfo = jSONObject.getJSONObject("booking_info").getJSONObject("provider_info");
                        String provider_email = providerInfo.getString("email");
                        String provider_phone = providerInfo.getString("phone_nb");
                        String provider_name;
                        if (providerInfo.getString("UserRole").toLowerCase(Locale.ROOT).equals("center")) {
                            provider_name = providerInfo.getString("f_name");
                        } else {
                            provider_name = providerInfo.getString("f_name") + " " + providerInfo.getString("l_name");
                        }
                        Log.d("BookInfo", "hi4");
                        String provider_icon = providerInfo.getString("icon");
                        String provider_id = providerInfo.getString("user_id");


                        String offer_id = "", offer_price = "", offer_time = "", offer_description = "", offer_icon = "";
                        if (!jSONObject.isNull("offer_info")) {
                            offer_id = jSONObject.getJSONObject("offer_info").getString("offer_id");
                            offer_description = jSONObject.getJSONObject("offer_info").getString("description");
                            offer_price = jSONObject.getJSONObject("offer_info").getString("price");
                            offer_time = jSONObject.getJSONObject("offer_info").getString("time");
                            offer_icon = jSONObject.getJSONObject("offer_info").getString("icon");
                        }

                        String payment_id = "", payment_type = "", payment_amount = "";
                        if (!jSONObject.isNull("payment_info")) {
                            payment_amount = jSONObject.getJSONObject("payment_info").getString("AmountPaid");
                            payment_id = jSONObject.getJSONObject("payment_info").getString("PaymentID");
                            payment_type = jSONObject.getJSONObject("payment_info").getString("PaymentMethod");
                        }
                        ArrayList<ServiceModel> arrayService = new ArrayList<>();
                        if (!jSONObject.getJSONArray("services").isNull(0)) {
                            int j = 0;
                            JSONArray jsonArrayServices = new JSONArray(jSONObject.getString("services"));

                            while (j < jsonArrayServices.length()) {
                                JSONObject jb = jsonArrayServices.getJSONObject(j);
                                String id = jb.getString("ServiceID");
                                String name = jb.getString("ServiceName");
                                String price = jb.getString("ServicePrice");
                                String s_provider_id = jb.getString("s_provider_id");
                                arrayService.add(new ServiceModel(id, name, price, s_provider_id));
                                j++;
                            }
                        }
                        status.setText(book_status.toUpperCase(Locale.ROOT));
                        if (book_status.toLowerCase(Locale.ROOT).equals("pending")) {
                            status.setTextColor(getResources().getColor(R.color.orange));
                            ic_help.setVisibility(View.GONE);
                        } else if (book_status.toLowerCase(Locale.ROOT).equals("accepted")) {
                            status.setTextColor(getResources().getColor(R.color.lime));
                            ic_help.setVisibility(View.GONE);
                        } else if (book_status.toLowerCase(Locale.ROOT).equals("rejected")) {
                            ic_help.setVisibility(View.VISIBLE);
                            status.setTextColor(getResources().getColor(R.color.red, null));
                            ic_help.setOnClickListener(v -> {
                                AlertDialog.Builder builder = new AlertDialog.Builder(BookInfo.this);
                                builder.setTitle("Reason of rejection");
                                builder.setMessage(rejection_cause);
                                builder.setPositiveButton("Close", null);
                                builder.show();
                            });
                        } else {
                            ic_help.setVisibility(View.GONE);
                            status.setTextColor(getResources().getColor(R.color.purple));
                        }
                        layout_provider.setOnClickListener(view -> {
                            Intent intent = new Intent(BookInfo.this, UserProfile.class);
                            intent.putExtra("user_id", provider_id);
                            startActivity(intent);
                        });
                        layout_parent.setOnClickListener(view -> {
                            Intent intent = new Intent(BookInfo.this, UserProfile.class);
                            intent.putExtra("user_id", parent_id);
                            startActivity(intent);
                        });
                        icon_call_provider.setOnClickListener(view -> {
                            Intent intent = new Intent(Intent.ACTION_DIAL);
                            intent.setData(Uri.parse("tel:" + provider_phone + ""));
                            startActivity(intent);
                        });
                        icon_call_parent.setOnClickListener(view -> {
                            Intent intent = new Intent(Intent.ACTION_DIAL);
                            intent.setData(Uri.parse("tel:" + parent_phone + ""));
                            startActivity(intent);
                        });

                        icon_email_parent.setOnClickListener(v -> {
                            Intent intent = new Intent(Intent.ACTION_SENDTO);
                            intent.setData(Uri.parse("mailto:" + parent_email));
                            intent.putExtra(Intent.EXTRA_EMAIL, parent_email);
                            intent.putExtra(Intent.EXTRA_SUBJECT, "");
                            startActivity(intent);

                        });

                        icon_email_provider.setOnClickListener(v -> {
                            Intent intent = new Intent(Intent.ACTION_SENDTO);
                            intent.setData(Uri.parse("mailto:" + provider_email));
                            intent.putExtra(Intent.EXTRA_EMAIL, provider_email);
                            intent.putExtra(Intent.EXTRA_SUBJECT, "");
                            startActivity(intent);

                        });

                        this.offer_info.setText(offer_description + " (" + offer_price + "$)");
                        this.offer_info.setPaintFlags(this.offer_info.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

                        this.date.setText(bookingDate);
                        this.provider_name.setText(provider_name);
                        this.parent_name.setText(parent_name);

                        payment_info.setText(payment_amount + "$ (" + payment_type.toUpperCase(Locale.ROOT) + ")");
                        if (offer_id.equals("")) {
                            layout_offer.setVisibility(View.GONE);
                            layout_service.setVisibility(View.VISIBLE);
                        } else {
                            layout_offer.setVisibility(View.VISIBLE);
                            layout_service.setVisibility(View.GONE);
                        }
                        for (int j = 0; j < arrayService.size(); j++) {
                            Chip chip = (Chip) View.inflate(BookInfo.this, R.layout.chip_items_read, null);
                            chip.setText(arrayService.get(j).getName() + " - " + arrayService.get(i).getPrice());
                            chipGroup.addView(chip);
                        }

                        // Decode and set parent icon
                        try {
                            byte[] parentIconBytes = Base64.decode(parent_icon, Base64.DEFAULT);
                            Bitmap parentIconBitmap = BitmapFactory.decodeByteArray(parentIconBytes, 0, parentIconBytes.length);
                            icon_parent.setImageBitmap(parentIconBitmap);
                        } catch (Exception e) {
                            Log.e("BookInfo", "Error decoding parent icon: " + e.getMessage());
                        }

                        // Decode and set provider icon
                        try {
                            byte[] providerIconBytes = Base64.decode(provider_icon, Base64.DEFAULT);
                            Bitmap providerIconBitmap = BitmapFactory.decodeByteArray(providerIconBytes, 0, providerIconBytes.length);
                            icon_provider.setImageBitmap(providerIconBitmap);
                        } catch (Exception e) {
                            Log.e("BookInfo", "Error decoding provider icon: " + e.getMessage());
                        }

                        i++;
                    }

                } catch (Exception | Error e) {
                    Log.e("BookInfo", "Exception caught in getInfo(): ", e);
                }
            }
        }, error -> {
            Log.e("BookInfo", "Volley Error: ", error);
        });

        RequestQueue requestQueue = Volley.newRequestQueue(BookInfo.this);
        requestQueue.add(stringRequest);
    }



    private Bitmap decodeBase64(String base64) {
        byte[] decodedBytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }

}
