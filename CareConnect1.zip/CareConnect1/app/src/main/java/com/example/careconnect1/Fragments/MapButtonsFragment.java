package com.example.careconnect1.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.careconnect1.R;

public class MapButtonsFragment extends Fragment {

    public MapButtonsFragment() {
    }

    public static MapButtonsFragment newInstance() {
        return new MapButtonsFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_map_buttons, container, false);

        Button btnViewAllBabysitters = rootView.findViewById(R.id.btnViewAllProviders);
        Button btnViewNearbyBabysitters = rootView.findViewById(R.id.btnViewNearbyProviders);

        // Set click listener for "View All Babysitters" button
        btnViewAllBabysitters.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fetchAllBabysitters();  // Fetch and display all babysitters
            }
        });

        // Set click listener for "View Nearby Babysitters" button
        btnViewNearbyBabysitters.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filterNearestBabysitters();  // Filter and display nearby babysitters
            }
        });
        return rootView;
    }

    // Method to fetch all babysitters
    private void fetchAllBabysitters() {
        navigateToMapViewFragment(true, false);
    }

    // Method to filter and display nearby babysitters
    private void filterNearestBabysitters() {
        navigateToMapViewFragment(false, true);
    }

    // Method to navigate to MapViewFragment with specified flags
    private void navigateToMapViewFragment(boolean showAllBabysitters, boolean showNearestBabysitters) {
        // Create instance of MapViewFragment
        MapViewFragment mapViewFragment = MapViewFragment.newInstance();

        // Start a FragmentTransaction
        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();

        // Pass the flags as arguments to MapViewFragment
        Bundle args = new Bundle();
        args.putBoolean("showAllBabysitters", showAllBabysitters);
        args.putBoolean("showNearestBabysitters", showNearestBabysitters);
        mapViewFragment.setArguments(args);

        // Replace the fragment_container2 with MapViewFragment
        transaction.replace(R.id.fragment_container2, mapViewFragment);

        // Add transaction to back stack for back navigation
        transaction.addToBackStack(null);

        // Commit the transaction
        transaction.commit();
    }
}