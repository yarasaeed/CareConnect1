package com.example.careconnect1.Fragments;

import static com.example.careconnect1.Utilities.Config.IP;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.careconnect1.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.osmdroid.api.IMapController;
import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.infowindow.InfoWindow;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

import java.util.ArrayList;
import java.util.List;

public class MapViewFragment extends Fragment implements Marker.OnMarkerClickListener {

    private static final int REQUEST_LOCATION_PERMISSION = 123;
    private MapView mMap;
    private IMapController controller;
    private MyLocationNewOverlay mMyLocationOverlay;
    private GeoPoint parentLocation;
    private List<Provider> providers = new ArrayList<>();
    private InfoWindow currentInfoWindow;


    public static MapViewFragment newInstance() {
        return new MapViewFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_map_view, container, false);
        mMap = rootView.findViewById(R.id.osmmap);
        mMap.setTileSource(TileSourceFactory.MAPNIK);
        mMap.setMultiTouchControls(true);
        controller = mMap.getController();
        controller.setZoom(15.0);
        mMyLocationOverlay = new MyLocationNewOverlay(new GpsMyLocationProvider(requireContext()), mMap);
        mMyLocationOverlay.enableMyLocation();
        mMyLocationOverlay.enableFollowLocation();
        mMyLocationOverlay.setDrawAccuracyEnabled(true);
        mMap.getOverlays().add(mMyLocationOverlay);
        Configuration.getInstance().load(getContext(), PreferenceManager.getDefaultSharedPreferences(getContext()));
        Log.e("Empty Response", "Empty responseeeee");
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_PERMISSION);
        } else {
            getDeviceLocation();
        }

        fetchProviders();
        return rootView;
    }

    private void fetchProviders() {
        String url = IP + "fetch_babysitters.php";

        Log.d("Network Request", "Fetching providers from URL: " + url); // Log network request

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        handleResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        handleError(error);
                    }
                }
        );

        // Add the request to the RequestQueue
        Volley.newRequestQueue(requireContext()).add(jsonArrayRequest);
    }

    private void handleResponse(JSONArray response) {
        Log.d("Network Response", "Response received: " + response.toString()); // Log network response
        if (response != null && response.length() > 0) {
            // Non-empty response, parse the JSON data
            try {
                for (int i = 0; i < response.length(); i++) {
                    JSONObject jsonObject = response.getJSONObject(i);
                    double lat = Double.parseDouble(jsonObject.getString("latitude"));
                    double lon = Double.parseDouble(jsonObject.getString("longitude"));
                    String role = jsonObject.getString("role");
                    String name = jsonObject.getString("name");
                    String phone = jsonObject.getString("phone_nb"); // Get phone number from JSON

                    // Create a Provider object
                    Provider provider = new Provider(new GeoPoint(lat, lon), name, role, phone);
                    providers.add(provider);
                    Log.d("Provider", provider.toString());
                }

            } catch (JSONException e) {
                e.printStackTrace();
                // Handle JSON parsing error
                Log.e("JSON Parsing Error", "Error parsing JSON data: " + e.getMessage());
            }
        } else {
            // Empty response
            Log.e("Empty Response", "Empty response received from the server");
        }
    }


    private void handleError(VolleyError error) {
        // Handle Volley error
        Log.e("Volley Error", "Error fetching data: " + error.getMessage());
        // Handle server error scenario
    }

    private Provider findNearestBabysitter(GeoPoint userLocation, List<Provider> providers) {
        Provider nearestBabysitter = null;
        double minDistance = Double.MAX_VALUE;

        for (Provider provider : providers) {
            if (provider.getRole().equals("babysitter") || provider.getRole().equals("center")) {
                double distance = calculateDistance(userLocation, provider.getLocation());
                if (distance < minDistance) {
                    minDistance = distance;
                    nearestBabysitter = provider;
                }
            }
        }

        return nearestBabysitter;
    }

    private double calculateDistance(GeoPoint point1, GeoPoint point2) {
        if (point1 == null || point2 == null) {
            // Handle null GeoPoint objects
            return Double.MAX_VALUE; // Or any other appropriate value
        }

        double earthRadius = 6371.0; // Earth's radius in kilometers

        double latDiff = Math.toRadians(point2.getLatitude() - point1.getLatitude());
        double lonDiff = Math.toRadians(point2.getLongitude() - point1.getLongitude());

        double a = Math.sin(latDiff / 2) * Math.sin(latDiff / 2) +
                Math.cos(Math.toRadians(point1.getLatitude())) * Math.cos(Math.toRadians(point2.getLatitude())) *
                        Math.sin(lonDiff / 2) * Math.sin(lonDiff / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        return earthRadius * c;
    }


    private void getDeviceLocation() {
        mMyLocationOverlay.runOnFirstFix(() -> {
            parentLocation = mMyLocationOverlay.getMyLocation();
            if (parentLocation != null) {
                // Create a handler to post a Runnable to the main UI thread
                new Handler(Looper.getMainLooper()).post(() -> {
                    // Add a marker for the parent's location
                    Marker parentMarker = new Marker(mMap);
                    parentMarker.setPosition(parentLocation);
                    parentMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
                    mMap.getOverlays().add(parentMarker);
                    Log.e("Empty Response", "Empty responseeeee");
                    // Center the map around the parent's location
                    controller.animateTo(parentLocation);

                    // Update the map markers to include the parent marker
                    updateMapMarkers();
                });
            }
        });
    }

    private void updateMapMarkers() {
        mMap.getOverlays().clear();
        mMap.getOverlays().add(mMyLocationOverlay);

        if (parentLocation != null) {
            Marker parentMarker = new Marker(mMap);
            parentMarker.setPosition(parentLocation);
            parentMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
            mMap.getOverlays().add(parentMarker);
        }

        // Check the flags passed from MapButtonsFragment
        Bundle args = getArguments();
        if (args != null) {
            boolean showAllBabysitters = args.getBoolean("showAllBabysitters", false);
            boolean showNearestBabysitters = args.getBoolean("showNearestBabysitters", false);
            boolean showHighRatedBabysitters = args.getBoolean("showHighRatedBabysitters", false);

            if (showAllBabysitters) {
                // Update markers to show all babysitters
                for (Provider provider : providers) {
                    addMapMarker(provider);
                }
            } else if (showNearestBabysitters) {
                // Find and update marker for nearest babysitter
                Provider nearestBabysitter = findNearestBabysitter(parentLocation, providers);
                if (nearestBabysitter != null) {
                    addMapMarker(nearestBabysitter);
                }
            }
        }
    }

    @Override
    public boolean onMarkerClick(Marker marker, MapView mapView) {
        // Check if there's currently an open info window
        if (currentInfoWindow != null && currentInfoWindow.isOpen()) {
            // Close the current info window
            currentInfoWindow.close();
        }

        // Find the provider associated with the clicked marker
        for (Provider provider : providers) {
            if (provider.getLocation().equals(marker.getPosition())) {
                // Show the info window for the clicked marker
                currentInfoWindow = showProviderInfo(provider);
                return true;
            }
        }
        return false;
    }

    private void addMapMarker(Provider provider) {
        Marker marker = new Marker(mMap);
        marker.setPosition(provider.getLocation());
        marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        if (provider.getRole().equals("center")) {
            // Use center marker icon
            marker.setIcon(ContextCompat.getDrawable(requireContext(), R.drawable.center));
        } else if (provider.getRole().equals("babysitter")) {
            // Use babysitter marker icon
            marker.setIcon(ContextCompat.getDrawable(requireContext(), R.drawable.ic_users));
        } else {
            // Use default marker icon
            marker.setIcon(ContextCompat.getDrawable(requireContext(), R.drawable.ic_user));
        }
        marker.setTitle(provider.getName());
        marker.setSnippet(provider.getPhone()); // Set phone number as the snippet

        // Set click listener for the marker
        marker.setOnMarkerClickListener((Marker clickedMarker, MapView clickedMapView) -> {
            // Show information window when marker is clicked
            showProviderInfo(provider);
            return true; // Return true to consume the event
        });

        mMap.getOverlays().add(marker);
    }

    private InfoWindow showProviderInfo(Provider provider) {
        // Inflate layout for information window
        LayoutInflater inflater = (LayoutInflater) requireContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View popup = inflater.inflate(R.layout.marker_info_window, null);

        // Set provider information to the layout views
        TextView textName = popup.findViewById(R.id.textName);
        TextView textPhone = popup.findViewById(R.id.textPhone);
        textName.setText(provider.getName());
        textPhone.setText(provider.getPhone());

        // Create an info window and open it above the marker
        InfoWindow infoWindow = new InfoWindow(popup, mMap) {
            @Override
            public void onOpen(Object item) {
            }

            @Override
            public void onClose() {
                // Clear the currentInfoWindow when it's closed
                currentInfoWindow = null;
            }
        };

        if (currentInfoWindow != null && currentInfoWindow.isOpen()) {
            // Close the current info window
            currentInfoWindow.close();
        }

        infoWindow.open(popup, provider.getLocation(), 0, 0);
        currentInfoWindow = infoWindow;

        return infoWindow; // Return the created info window
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_LOCATION_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getDeviceLocation();
            }
        }
    }

    private static class Provider {
        private GeoPoint location;
        private String name;
        private String role;
        private String phone; // Add phone field

        public Provider(GeoPoint location, String name, String role, String phone) {
            this.location = location;
            this.name = name;
            this.role = role;
            this.phone = phone; // Initialize phone field
        }

        public GeoPoint getLocation() {
            return location;
        }

        public String getName() {
            return name;
        }

        public String getRole() {
            return role;
        }

        public String getPhone() {
            return phone; // Return phone number
        }

        @Override
        public String toString() {
            return "Provider{" +
                    "name='" + name + '\'' +
                    ", role='" + role + '\'' +
                    ", phone='" + phone + '\'' +
                    ", location=" + location +
                    '}';
        }
    }

}