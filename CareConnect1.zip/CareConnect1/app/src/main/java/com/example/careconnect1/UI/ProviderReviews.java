package com.example.careconnect1.UI;

import static com.example.careconnect1.Utilities.Config.IP;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.careconnect1.Adapters.ProviderReviewsAdapter;
import com.example.careconnect1.Model.ReviewsModel;
import com.example.careconnect1.R;
import com.example.careconnect1.Utilities.AppCompatClass;
import com.example.careconnect1.Utilities.UserData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import android.util.Base64;

public class ProviderReviews extends AppCompatClass {
    private RecyclerView recyclerView;
    private ArrayList<ReviewsModel> arrayList;
    private UserData userData;
    private ProviderReviewsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_provider_reviews);
        setMethods("Reviews", "");
    }

    @Override
    public void setInitialize() {
        super.setInitialize();
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        userData = new UserData(ProviderReviews.this);
    }

    @Override
    public void setActions() {
        super.setActions();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getReviews();
    }

    public void getReviews() {
        arrayList = new ArrayList<>();
        String url = IP + "select_reviews_where_provider.php?provider_id=" + userData.getId();
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    if (jsonArray.length() == 0) {
                        Toast.makeText(ProviderReviews.this, "There are no reviews", Toast.LENGTH_SHORT).show();
                    } else {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject reviewObject = jsonArray.getJSONObject(i);
                            String text = reviewObject.optString("ReviewText");
                            String user_id = reviewObject.optString("UserID");
                            String id = reviewObject.optString("ReviewID");
                            String provider_id = reviewObject.optString("ProviderID");
                            String book_id = reviewObject.optString("r_booking_id");
                            JSONObject parentInfoObject = reviewObject.optJSONObject("parent_info");
                            String parent_name = parentInfoObject.optString("f_name") + " " + parentInfoObject.optString("l_name");
                            String parent_iconBase64 = parentInfoObject.optString("icon");
                            String date = reviewObject.optString("date");
                            Bitmap parent_icon = decodeBase64(parent_iconBase64);
                            arrayList.add(new ReviewsModel(id, book_id, user_id, provider_id, text, parent_name, parent_icon, date));
                        }
                        adapter = new ProviderReviewsAdapter(ProviderReviews.this, arrayList, false);
                        recyclerView.setAdapter(adapter);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();

            }

        }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(ProviderReviews.this);
        requestQueue.add(stringRequest);
    }

    // Decode Base64 string to Bitmap
    private Bitmap decodeBase64(String base64) {
        byte[] decodedBytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }
}
