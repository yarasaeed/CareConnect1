package com.example.careconnect1.Model;

import android.graphics.Bitmap;

public class UsersModel {
    private String user_id, name, role, phone, email;
    private Bitmap icon;

    public UsersModel(String user_id, String name, String role, String phone, String email, Bitmap icon) {
        this.user_id = user_id;
        this.name = name;
        this.role = role;
        this.phone = phone;
        this.email = email;

        this.icon = icon;
    }

    // Getters and setters
    public String getUser_id() {
        return user_id;
    }

    public String getName() {
        return name;
    }

    public String getRole() {
        return role;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }


    public Bitmap getIcon() {
        return icon;
    }
}
